import { Author } from './author';

export type Post = {
    title: string;
    slug: string;
    heroImage: any;
    description: string;
    body: any;
    tags: string[];
    readTimeEstimate: string;
    author: Author;
    publishDate: Date;
};
