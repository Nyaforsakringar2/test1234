export const BLOG_PATH = '/forsakringsguiden';
export const getNavigationLink = (slug: string) => `${BLOG_PATH}/${slug}`;
export const getHref = () => `${BLOG_PATH}/[slug]`;
