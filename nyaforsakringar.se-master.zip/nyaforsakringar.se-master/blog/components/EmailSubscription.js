import React from 'react';
import * as s from '../styles/EmailSubscription.module.css';
import Button from '../../components/shared/Button';

const EmailSubscription = () => {
    return (
        <section className={s.sectionContainer}>
            <div className={s.sectionInnerContainer}>
                <h1>NYHETSBREV</h1>
                <p>
                    FÅ NYHETER OM FÖRSÄKRINGAR SKICKADE TILL DIG.
                </p>
                <div className={s.emailSubscription}>
                    <input id="email" name="email" type="email" placeholder="Enter your email" required="" />
                    <Button
                        className={s.button}
                        innerClassName={s.buttonInner}
                        titleClassName={s.buttonTitle}
                        title="Subscribe"
                    />
                </div>
                <span>
                    We will treat your data with respect and you can find the details in our privacy and cookie policy,
                    and our website terms of use.
                </span>
            </div>
        </section>
    )
};

export default EmailSubscription;
