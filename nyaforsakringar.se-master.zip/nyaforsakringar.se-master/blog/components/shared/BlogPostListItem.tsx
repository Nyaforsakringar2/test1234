import React, { FunctionComponent } from 'react';
import Link from 'next/link';
import Moment from 'react-moment';
import { getHref, getNavigationLink } from '../../helpers/urlHelper';

const s = require('../../styles/shared/BlogPostListItem.module.css');

type Props = {
    info: { id: string, title: string; description: string; heroImage: string; publishedAt: Date; slug: string, tags: any }
}

const BlogPostListItem: FunctionComponent<Props> = ({info}) => {
    return (
        <Link href={getHref()} as={getNavigationLink(info.slug)}>
            <a className={s.blogPostContainer}>
                <img src={info.heroImage} alt="post image" />
                <div className={s.infoContainer}>
                    <span className={s.postCategory}>{info.tags[0].fields.name}</span>
                    <h2>{info.title}</h2>
                    <em className={s.postDate}>
                        <Moment date={info.publishedAt} format="DD MMMM YYYY" />
                    </em>
                </div>
            </a>
        </Link>
    );
};

export default BlogPostListItem;
