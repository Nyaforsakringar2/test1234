import React from 'react';
import * as s from '../styles/Hero.module.css';
import Button from '../../components/shared/Button';

const Hero = () => {
    return (
        <section className={s.sectionContainer}>
            <header>
                <h1>Bilförsäkring​</h1>
                <p>
                    Vi söker efter försäkringar hos alla försäkringsbolag anpassat efter dina behov . Men innan du ska
                    välja har vi satt ihop information för att göra valet enklare och du får även reda på vad som händer
                    när skadan är framme.
                </p>
                <Button
                  className={s.button}
                  innerClassName={s.buttonInner}
                  titleClassName={s.buttonTitle}
                  title="läs mer"
                />
            </header>
        </section>
    )
};

export default Hero;
