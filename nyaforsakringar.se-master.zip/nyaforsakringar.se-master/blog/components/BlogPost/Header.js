import React from 'react';
import Link from 'next/link';
import * as s from '../../styles/BlogPost/Header.module.css';
import Moment from 'react-moment';
import ReactMarkdown from 'react-markdown';
import { BLOG_PATH } from '../../helpers/urlHelper';

const Header = (props) => {
    return (
        <section className={s.sectionContainer}>
            <div className={s.sectionContainerInner}>
                <span className={s.postCategory}>
                    <Link href={BLOG_PATH}>
                        <a>
                            Blog
                        </a>
                    </Link>
                    &nbsp;/&nbsp;
                    <Link href={`${BLOG_PATH}?t=${props.article.tags[0].id}`}>
                        <a>
                            {props.article.tags[0].name}
                        </a>
                    </Link>
                </span>
                <h1>
                    {props.article.title}
                </h1>
                <ReactMarkdown source={props.article.description} />
                <em>
                    By {props.article.author.name} •&nbsp;
                    <Moment date={props.article.publishedAt} format="MMMM DD, YYYY" />
                    { props.article.readTimeEstimate ? ` • ${props.article.readTimeEstimate}` : '' }
                </em>
                <img src={props.article.heroImage.url} alt="blogpost picture" />
            </div>
        </section>
    );
};

export default Header;
