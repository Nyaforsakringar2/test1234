import React from 'react';
import * as s from '../../styles/BlogPost/Content.module.css';
import ReactMarkdown from 'react-markdown';

const Content = (props) => {
    return (
        <section className={s.sectionContainer}>
            <div className={s.sectionContainerInner}>
                <ReactMarkdown source={props.article.body} />
            </div>
            <ul className={s.socialSharingContainer}>
                <li className={s.socialShareFB}>
                    <a href="">
                        facebook
                    </a>
                </li>
                <li className={s.socialShareTW}>
                    <a href="">
                        twitter
                    </a>
                </li>
                <li className={s.socialShareLI}>
                    <a href="">
                        linkedin
                    </a>
                </li>
            </ul>
        </section>
    );
};

export default Content;
