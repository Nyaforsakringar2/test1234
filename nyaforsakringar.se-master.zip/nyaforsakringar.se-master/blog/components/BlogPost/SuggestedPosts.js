import { BlogPostListItem } from '../';
import * as s from '../../styles/BlogPost/SuggestedPosts.module.css';
import React from "react";

const SuggestedPosts = (props) => {
    const suggestedPosts = props.suggestedArticles.entries.map((entry, index) => (
        <li className="col-12 col-sm-6 col-md-4" key={index}>
             <BlogPostListItem info={entry} />
        </li>
    ));

    return (
        <section className={s.sectionContainer}>
            <h1>
                You may also like
            </h1>
            <ul className={`${s.blogPostsList} row`}>
                {suggestedPosts}
            </ul>
        </section>
    );
};

export default SuggestedPosts;
