import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router'
import * as s from '../styles/BlogPostsList.module.css';
import Button from '../../components/shared/Button';
import { BlogPostListItem } from './';
import Select from 'react-select';
import { BLOG_PATH } from '../helpers/urlHelper';

const filterStyles = {
    container: () => ({
        position: 'relative',
        width: '256px'
    }),
    control: () => ({
        alignItems: 'center',
        backgroundColor: '#ffffff',
        border: '1px solid #CCCCCC',
        borderRadius: '8px',
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'space-between',
        minHeight: '38px',
        outline: '0 !important',
        position: 'relative',
        transition: 'all 100ms'
    }),
    indicatorSeparator: () => ({
        background: 'none'
    }),
    indicatorsContainer: () => ({
        alignItems: 'center',
        alignSelf: 'stretch',
        display: 'flex',
        flexShrink: 0,
        padding: '0 0.75em 0 0',
        color: '#000000'
    }),
    valueContainer: () => ({
        alignItems: 'center',
        display: 'flex',
        flex: 1,
        flexWrap: 'wrap',
        padding: '0.75em 1em',
        position: 'relative',
        overflow: 'hidden'
    }),
    placeholder: () => ({
        color: '#666666',
        fontSize: '1em',
        lineHeight: '1.5em',
        marginLeft: '2px',
        marginRight: '2px',
        position: 'absolute',
        top: '50%',
        transform: 'translateY(-50%)'
    }),
    input: () => ({
        margin: '2px',
        paddingBottom: '2px',
        paddingTop: '2px',
        visibility: 'visible',
        color: '#666666',
        fontSize: '1em',
        lineHeight: '1.5em'
    })
};

const BlogPosts = (entries) => entries.map((entry, index) => (
    <li className={`${s.post} col-12 col-sm-6 col-md-4`} key={index}>
        <BlogPostListItem info={entry} />
    </li>
));

const filterDefaultOption = { value: 'all', label: 'Alla kategorier' };
const defaultPostsNumber = 9;
const filterOptions = (tags) => (
    [
        filterDefaultOption,
        ...tags.map((tag) => ({ value: tag.id, label: tag.name }))
    ]
);
const filterValueFromURL = (filterValue, filterOptions, router) => {
    if (Array.isArray(filterValue) && !filterValue.length && router.query?.t) { // isArray when it's a default value - bug of react-select lib
        return filterOptions.filter(option => option.value === router.query.t)[0];
    } else {
        return null;
    }
};

const BlogPostsList = (props) => {
    const router = useRouter();
    const [shownPostsNumber, setShownPostsNumber] = useState(props.limit || defaultPostsNumber);
    const onLoadMoreClick = () => {
        setShownPostsNumber(shownPostsNumber + defaultPostsNumber);
    };
    const [filterValue, setFilterValue] = useState([]);
    const onFilterChange = (filterOption) => {
        if (filterOption.value === filterValue) return;
        setFilterValue(filterOption.value);
        setShownPostsNumber(defaultPostsNumber);
    };
    const filterOptions = [
        filterDefaultOption,
        ...props.tags.map((tag) => ({ value: tag.id, label: tag.name }))
    ];
    const filterDefaultValue = filterValueFromURL(filterValue, filterOptions, router);
    const entries = props.entries?.length ? props.entries : [];
    const showLoadMoreButton = props.total > entries.length;

    useEffect(() => {
        let query = {};

        if (shownPostsNumber !== defaultPostsNumber) query.s = shownPostsNumber;
        if (filterValue.length) {
            if (filterValue === filterDefaultOption.value) {
                delete query.t;
            } else {
                query.t = filterValue;
            }
        } else if (router.query?.t) { // for page open with query preset case
            query.t = router.query.t;
        }

        void router.push({ pathname: BLOG_PATH, query: query });
    }, [shownPostsNumber, filterValue]);

    return (
        <section className={s.sectionContainer}>
            <div className={s.filterContainer}>
                <span>
                    Browse by category:
                </span>
                <Select
                    instanceId="blogPostsFilter"
                    defaultValue={filterDefaultValue}
                    value={filterValue.value}
                    onChange={onFilterChange}
                    options={filterOptions}
                    styles={filterStyles}
                />
            </div>
            {
                BlogPosts(entries).length ? (
                    <ul className={`${s.postsContainer} row`}>
                        { BlogPosts(entries) }
                    </ul>
                ) : (
                    <h2 className={s.postsLoadingErrorMsg}>
                        Tyvärr, men det finns inga inlägg i den här kategorin
                    </h2>
                )
            }
            { showLoadMoreButton ? (
                <div className={s.buttonContainer}>
                    <Button title="Läs mer om oss" style="blue" onPress={onLoadMoreClick} />
                </div>
            ) : null }
        </section>
    )
};

export default BlogPostsList;
