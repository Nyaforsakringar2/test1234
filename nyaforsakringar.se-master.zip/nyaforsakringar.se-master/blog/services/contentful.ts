import { createClient } from 'contentful';

export const CONTENT_TYPE_BLOGPOST = 'blogPost';
export const CONTENT_TYPE_PERSON = 'author';
export const CONTENT_TYPE_TAGS = 'tag';

const Space = process.env.CONTENTFUL_SPACE;
const Token = process.env.CONTENTFUL_TOKEN;

export class ContentfulService {
    private client = createClient({
        space: Space,
        accessToken: Token
    });

    async fetchPostBySlug(slug) {
        return await this.client.getEntries({
            content_type: CONTENT_TYPE_BLOGPOST,
            'fields.slug': slug,
            locale: 'sv-SE'
        });
    }

    async getAllTags() {
        const content = await this.client.getEntries({
            content_type: CONTENT_TYPE_TAGS,
            locale: 'sv-SE'
        });

        const tags = content.items.map(
            ({ sys, fields }: { sys: any; fields: any }) => ({
                id: sys.id,
                name: fields.name
            })
        );

        return { tags };
    }

    public async getBlogPostEntries(
        { limit, skip, tag, excludePostIds }: { limit?: number; skip?: number; tag?: string, excludePostIds?: string } = {
            limit: 9,
            skip: 0,
            tag: '',
            excludePostIds: ''
        }
    ) {
        try {
            const contents = await this.client.getEntries({
                include: 1,
                limit,
                skip,
                'fields.tags.sys.id': tag,
                'sys.id[nin]': excludePostIds,
                content_type: CONTENT_TYPE_BLOGPOST,
                order: 'fields.publishDate',
                locale: 'sv-SE'
            });

            const entries = contents.items
                .map(({ sys, fields }: { sys: any; fields: any }) => ({
                    id: sys.id,
                    title: fields.title,
                    description: fields.description,
                    heroImage: fields.heroImage.fields.file.url,
                    slug: fields.slug,
                    tags: fields.tags,
                    publishedAt: fields.publishDate
                        ? new Date(fields.publishDate)
                        : new Date(sys.createdAt)
                }));

            const total = contents.total;

            return { entries, total, limit, skip };
        } catch (error) {
            // TODO: add error handling
            console.log(error);
        }
    }

    async getPostBySlug(slug) {
        try {
            const content: any = await this.fetchPostBySlug(slug);

            const entry: { sys: any; fields: any } = content.items[0];
            const author = {
                name: entry.fields.author.fields.name,
                title: entry.fields.author.fields.title,
                company: entry.fields.author.fields.company,
                shortBio: entry.fields.author.fields.shortBio
            };
            const tags = entry.fields.tags.map((tag) => ({id: tag.sys.id, name: tag.fields.name.toLowerCase()}));

            return {
                id: entry.sys.id,
                slug: entry.fields.slug,
                body: entry.fields.body,
                title: entry.fields.title,
                description: entry.fields.description,
                heroImage: { url: entry.fields.heroImage.fields.file.url },
                readTimeEstimate: entry.fields.readTimeEstimate,
                author: { ...author, id: entry.fields.author.sys.id },
                tags: tags,
                publishedAt: entry.fields.publishDate
                    ? new Date(entry.fields.publishDate)
                    : new Date(entry.sys.createdAt)
            };
        } catch (error) {
            console.error(error);
        }
    }
}
