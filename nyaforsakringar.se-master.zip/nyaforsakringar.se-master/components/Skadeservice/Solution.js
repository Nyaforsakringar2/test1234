import * as s from '../../styles/Skadeservice/Solution.module.css';

const Solution = () => {
    return (
        <section className={s.sectionContainer}>
            <div className={`${s.firstContainer}  row`}>
                <div className={`${s.decorationPictureContainer} col-12 col-md-5`}>
                    <img src="/images/skadeservice/solution-ellipse-with-logo.png" alt="decoration image" className={s.decorationPicture} />
                </div>
                <div className={`${s.dataContainer} col-12 col-md-6 offset-md-1`}>
                    <h1>
                        LÖSNINGEN
                    </h1>
                    <strong>
                        Vi tar hand om skadorna.
                    </strong>
                    <p>
                        När skadan är framme hjälper Nya Försäkringar dig att få ersättning. Med smart teknik och våra
                        erfarna medarbetare, ser vi till att du får hjälp och rätt ersättning från försäkringen när du
                        som mest behöver det. Vi dokumenterar, informerar, korresponderar och företräder dig som kund efter en skada.
                    </p>
                    <img src="/images/skadeservice/solution-screen.png" alt="solution screen" />
                </div>
            </div>
            <div className={s.secondContainerOuter}>
                <div className={`${s.secondContainer} row`}>
                    <div className="col-12 col-md-5">
                        <h2>
                            Anmäl skada på Mina Sidor
                        </h2>
                        <p>
                            Du annmäler skadan på vår hemsida eller till någon av våra rådgivare. Vi tar hand om pappersarbetet,
                            läsa försäkringsvillkoren och att sitta i telefonköer.
                        </p>
                    </div>
                </div>
            </div>
            <div className={s.thirdContainerOuter}>
                <div className={s.thirdContainer}>
                    <h2>
                        Rätt försäkrad till rätt pris
                    </h2>
                    <p>
                        Rätt försäkrad till Rätt pris bygger på att vi tar ansvar hela vägen för att tillvarata våra kunders
                        intressen allt från tecknandet av försäkringen till att pengarna för skadan är utbetalda.
                        Vi tar helt enkelt bort allt det där tråkiga med försäkringar. Vi tycker att du enkelt ska få ut
                        den ersättning du har rätt till. Spara tid och Pengar.
                    </p>
                </div>
            </div>

        </section>
    )
};

export default Solution;
