import Hero from './Hero';
import Challenges from './Challenges';
import Solution from './Solution';

export {
    Hero,
    Challenges,
    Solution
};
