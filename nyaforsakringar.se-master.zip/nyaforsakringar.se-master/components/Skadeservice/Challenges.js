import * as s from '../../styles/Skadeservice/Challenges.module.css';

const Challenges = () => {
    return (
        <section className={s.sectionContainer}>
            <div className={s.descriptionOuterContainer}>
                <div className={s.description}>
                    <h1>
                        UTMANINGEN
                    </h1>
                    <p>
                        Ibland kan det vara krångligt att använda sig av försäkringen och det är lätt att missa ersättning.
                        Ibland är det krångligt att använda sig av försäkringen när man som mest behöver den.
                        Den bortappade telefonen och glasrutan som gick sönder är oftast inga problem och kan skötas digitalt.
                        Men när vattenskadan ska ersättas är det mycket som ska kordineras, fuktundersökning, fuktsanering,
                        fuktundersök- ning igen och sen ska det återställas med offerter, byggare och allt vad det heter.
                        Sedan uppstår det ofta olika uppfatt- ning om hur egendom ska värderas och om den ska ersättas.
                        Allt detta ska dokumenteras, korresponderas och tas om hand. Men inte längre nu kan du slippa det
                        samtidigt som du sparar pengar.
                    </p>
                </div>
            </div>
            <div className={s.picturesOuterContainer}>
                <div className={`${s.pictures} row`}>
                    <img src="/images/skadeservice/challenge-fire.png" alt="" className="d-none d-md-block col-md-6" />
                    <img src="/images/skadeservice/challenge-doctor.png" alt="" className="col-12 col-md-6" />
                </div>
            </div>
            <ul className={`${s.challengeFactors} row`}>
                <li className="col-12 col-md-4">
                    <h2 className="d-none d-md-block">
                        KRÄVER KUNSKAP  & TID
                    </h2>
                    <p>
                        För att få ersättning måste man veta att vad man har rätt till och det kan vara svårt att veta vilken
                        försäkring som täcker vad och hur mycket.  Det tar tid att sätta sig in i.
                    </p>
                </li>
              <li className="col-12 col-md-4">
                  <h2 className="d-none d-md-block">
                      KOMPLICERAT
                  </h2>
                  <p>
                      Att söka ersättning är komplicerat och involverar oftast långa telefonköer, många telefonsamtal och
                      blanketter som ska fyllas i.
                  </p>
              </li>
              <li className="col-12 col-md-4">
                  <h2 className="d-none d-md-block">
                      FÖRLORADE PENGAR
                  </h2>
                  <p>
                      Vi svenskar missar häpnadsväckande mycket ersättning från våra försäkringar varje år.
                      Både i premie och utebliven & felaktig ersättning.
                  </p>
              </li>
            </ul>
        </section>
    )
};

export default Challenges;
