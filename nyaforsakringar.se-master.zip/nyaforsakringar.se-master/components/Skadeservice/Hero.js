import * as s from '../../styles/Skadeservice/Hero.module.css';

const Hero = () => {
    return (
      <section className={s.sectionContainer}>
        <header>
          <h1>
            Skadeservice
          </h1>
          <p>
            Rätten är försäkrad till rätt pris.
          </p>
        </header>
      </section>
    )
};

export default Hero;
