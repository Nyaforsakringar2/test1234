import s from '../../styles/shared/Button.module.css';

const Button = ({title, onPress, style = '', className = '', innerClassName = '', titleClassName = ''}) => {
    return (
        <div className={`${s.button} ${s[style] ? s[style] : ''} ${className}`} onClick={onPress}>
            <div className={`${s.buttonInnerContainer} ${innerClassName}`}>
                <p className={`${s.buttonText} ${titleClassName}`}>
                    {title}
                </p>
            </div>
        </div>
    )
};

export default Button;
