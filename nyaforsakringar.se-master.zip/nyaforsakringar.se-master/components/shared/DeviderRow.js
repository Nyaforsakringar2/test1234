import React from 'react';
import * as s from '../../styles/shared/DeviderRow.module.css';

const DeviderRow = (params) => {
    return (
        <div className={`${s.deviderWrapper} ${params.className}`}>
            <div className={s.videoDeviderItem1}></div>
            <div className={s.videoDeviderItem2}></div>
            <div className={s.videoDeviderItem3}></div>
            <div className={s.videoDeviderItem4}></div>
        </div>
    )
};

export default DeviderRow;
