import * as s from '../../styles/shared/PreFooter.module.css';
import Button from '../shared/Button';

const PreFooter = (params) => {
  return (
    <section className={`${s.infoBlock} ${params.className}`}>
      <div className={s.information}>
        <div className={s.headerContainer}>
          <h2 className={s.header}>
            Få en kostnadsfri försäkringsrådgivning
          </h2>
        </div>
        <div className={s.descriptionContainer}>
          <p className={s.description}>
            Låt oss berätta mer vad vi kan göra för dig. Med vår kostnadsfria försäkringsrådgivning säkerställer du att du är rätt försäkrad till rätt pris.
          </p>
        </div>
        <div className={s.buttonContainer}>
          <Button title="Kontakta mig" />
        </div>
      </div>
    </section>
  )
};

export default PreFooter;
