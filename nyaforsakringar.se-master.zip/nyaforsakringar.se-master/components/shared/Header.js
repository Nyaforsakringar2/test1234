import React, {Component} from 'react';
import Link from 'next/link';
import DeviderRow from './DeviderRow';
import HeaderLink from './HeaderLink';
import * as s from '../../styles/shared/Header.module.css';
import {FormattedMessage} from 'react-intl';
import { IntlContext } from '../../locales/IntlProviderWrapper';

class Header extends Component {

    constructor() {
        super();
        this.state = {
            showMobileMenu: false,
        }
    }

    toggleMenu = (e) => {
        this.setState({showMobileMenu: !this.state.showMobileMenu})
    }

    render() {
        let {localizationValue} = this.state;
        const CustomToggle = React.forwardRef(({ children, onClick }, ref) => (
            <div
                ref={ref}
                onClick={e => {
                    e.preventDefault();
                    onClick(e);
                }}
            >
                {children}
            </div>
        ));

        const CustomMenu = React.forwardRef(
            ({ children, style, className, 'aria-labelledby': labeledBy }, ref) => {
                return (
                    <div
                        ref={ref}
                        style={style}
                        className={className}
                        aria-labelledby={labeledBy}
                    >
                        <ul className="list-unstyled">
                            {React.Children.toArray(children).filter(
                                child =>{
                                    return child.props.children.toLowerCase()
                                }
                            )}
                        </ul>
                    </div>
                );
            },
        );
        return (
            <IntlContext.Consumer>
                {({ switchToEnglish, switchToSweden, locale }) => (
                    <>
                    <header className={s.header}>
                        <div className={s.headerInnerWrapper}>
                            <div className={s.logoContainer}>
                                <Link href="/">
                                    <a className={s.logo}>
                                        <FormattedMessage id="app.header.logo" />
                                    </a>
                                </Link>
                            </div>
                            <ul className={s.linksContainer}>
                                <li className={s.link}>
                                    <HeaderLink href="/forsakringsservice" activeClassName={s.active}>
                                        <a className={s.linkText}>
                                            <FormattedMessage id="app.header.link1" />
                                        </a>
                                    </HeaderLink>
                                </li>
                                <li className={s.link}>
                                    <HeaderLink href="/skadeservice" activeClassName={s.active}>
                                        <a className={s.linkText}>
                                            <FormattedMessage id="app.header.link2" />
                                        </a>
                                    </HeaderLink>
                                </li>
                                <li className={s.link}>
                                    <HeaderLink href="/forsakringsguiden" activeClassName={s.active}>
                                        <a className={s.linkText}>
                                            <FormattedMessage id="app.header.link3" />
                                        </a>
                                    </HeaderLink>
                                </li>
                            </ul>
                            {/*Temporary not uses*/}
                            {/*
                            <div className={s.dropdownContainer}>
                                <Dropdown >
                                    <Dropdown.Toggle as={CustomToggle} id="dropdown-custom-components">
                                        <div className={s.dropdownToggle}>
                                            <div>
                                                <img src={'/images/se.png'}/>
                                            </div>
                                            <div>
                                                <img src={'/images/dropdown-arrow.png'}/>
                                            </div>
                                        </div>

                                    </Dropdown.Toggle>

                                    <Dropdown.Menu as={CustomMenu} className={s.dropdownMenu}>
                                        <Dropdown.Item onSelect={switchToSweden} eventKey="1" active={locale == 'se'}>se</Dropdown.Item>
                                        <Dropdown.Item onSelect={switchToEnglish} eventKey="2" active={locale == 'en'}>en</Dropdown.Item>
                                    </Dropdown.Menu>
                                </Dropdown>
                            </div>
                            */}
                            <div className={s.localeWithButtonsContainer}>
                                <div className={s.localeContainer}>
                                    <span className={s.localeFlag}>
                                        <FormattedMessage id="app.header.locale.flagFallback" />
                                    </span>
                                    <strong className={s.localeCode}>SE</strong>
                                </div>
                                <div className={s.buttonContainer}>
                                    <div
                                      className={s.buttonStyle}
                                      onClick={(e) => {
                                          this.toggleMenu(e)
                                      }}
                                    >
                                    <span className={s.buttonTextStyle}>
                                        <FormattedMessage id="app.header.button.text" />
                                    </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <DeviderRow />
                    </header>
                    <header className={`${s.mobileHeaderContainer} ${this.state.showMobileMenu ? s.menuOpened : ""}`} >
                        <div className={s.mobileHeaderInnerContainer}>
                            <div className={s.mobileHeader}>
                                <Link href="/">
                                    <a className={s.logo}>
                                        <FormattedMessage id="app.header.logo" />
                                    </a>
                                </Link>
                                <div className={s.buttonContainer} onClick={this.toggleMenu}>
                                    <a className={this.state.showMobileMenu ? s.opened : s.closed}>
                                        <FormattedMessage id="app.header.mobile.toggleMenu" />
                                    </a>
                                </div>
                            </div>
                            <div className={this.state.showMobileMenu ? s.mobileMenuVisible : s.hideMobileMenu}>
                                <ul className={s.titleList}>
                                    <li>
                                        <Link href="/forsakringsservice">
                                            <a>
                                                <FormattedMessage id="app.header.menu.title1" />
                                            </a>
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="/skadeservice">
                                            <a>
                                                <FormattedMessage id="app.header.menu.title2" />
                                            </a>
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="/forsakringsguiden">
                                            <a>
                                                <FormattedMessage id="app.header.menu.title3" />
                                            </a>
                                        </Link>
                                    </li>
                                </ul>
                                <ul className={s.linksList}>
                                    <li className={s.mobileMenuLink}>
                                        <Link href="/jamfor">
                                            <a className={s.menuLinkText}>
                                                <FormattedMessage id="app.header.menu.link1" />
                                            </a>
                                        </Link>
                                    </li>
                                    <li className={s.mobileMenuLink}>
                                        <Link href="/">
                                            <a className={s.menuLinkText}>
                                                <FormattedMessage id="app.header.menu.link2" />
                                            </a>
                                        </Link>
                                    </li>
                                    <li className={s.mobileMenuLink}>
                                        <Link href="/omoss">
                                            <a className={s.menuLinkText}>
                                                <FormattedMessage id="app.header.menu.link3" />
                                            </a>
                                        </Link>
                                    </li>
                                    <li className={s.mobileMenuLink}>
                                        <Link href="/forsakringsguiden">
                                            <a className={s.menuLinkText}>
                                                <FormattedMessage id="app.header.menu.link4" />
                                            </a>
                                        </Link>
                                    </li>
                                    <li className={s.mobileMenuLink}>
                                        <Link href="/faq">
                                            <a className={s.menuLinkText}>
                                                <FormattedMessage id="app.header.menu.link5" />
                                            </a>
                                        </Link>
                                    </li>
                                    <li className={s.mobileMenuLink}>
                                        <Link href="/">
                                            <a className={s.menuLinkText}>
                                                <FormattedMessage id="app.header.menu.link6" />
                                            </a>
                                        </Link>
                                    </li>
                                    <li className={s.mobileMenuLink}>
                                        <Link href="/contactus">
                                            <a className={s.menuLinkText}>
                                                <FormattedMessage id="app.header.menu.link7" />
                                            </a>
                                        </Link>
                                    </li>
                                </ul>

                                <div className={s.localeContainer}>
                                    <span className={s.localeFlag}>
                                        <FormattedMessage id="app.header.locale.flagFallback" />
                                    </span>
                                    <strong className={s.localeCode}>SE</strong>
                                </div>
                                {/*<div className={s.languaguesContainer}>
                                    <Dropdown>
                                        <Dropdown.Toggle as={CustomToggle} id="dropdown-custom-components">
                                            <div className={s.dropdownToggle}>
                                                <div>
                                                    <img src={'/images/se.png'}/>
                                                </div>
                                                <div>
                                                    <img src={'/images/dropdown-arrow.png'}/>
                                                </div>
                                            </div>

                                        </Dropdown.Toggle>

                                        <Dropdown.Menu as={CustomMenu} className={s.dropdownMenu}>
                                            <Dropdown.Item onSelect={switchToSweden} eventKey="1" active={locale == 'se'}>se</Dropdown.Item>
                                            <Dropdown.Item onSelect={switchToEnglish} eventKey="2" active={locale == 'en'}>en</Dropdown.Item>
                                        </Dropdown.Menu>
                                    </Dropdown>
                                </div>*/}
                            </div>
                        </div>
                    </header>
                    </>
                )}
            </IntlContext.Consumer>
        )
    }
}

export default Header;
