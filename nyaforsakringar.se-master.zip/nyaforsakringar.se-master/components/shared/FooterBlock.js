import Link from 'next/link'
import * as s from '../../styles/shared/FooterBlock.module.css';
import DeviderRow from './DeviderRow';

const FooterBlock = () => {
    return (
        <footer>
            <div className={s.footerContainer}>
                <div className={s.footerLogo}/>
                <div className={s.footerBgWrapper}>
                    <ul className={`${s.footerTextRows} row pl-3`}>
                        <li className={`${s.logoColumn} col-lg-5 col-md-4 col-sm-12 col-12 pb-0 pb-md-5`}>
                            <span className={s.logoSubText}>
                                Vi erbjuder Sveriges mest prisvärda försäkringar och skadeservice när olyckan väl är framme. Genom att ta ansvar hela vägen för att tillvarata våra kunders intressen tar vi bort allt det där tråkiga med försäkringar, som försäkringar borde fungera helt enkelt.
                            </span>
                            <ul className={s.socialIcons}>
                               <li>
                                   <Link href="/">
                                       <a className={s.fb}>facebook</a>
                                   </Link>
                               </li>
                                <li>
                                    <Link href="/">
                                        <a className={s.tw}>twitter</a>
                                    </Link>
                                </li>
                                <li>
                                    <Link href="/">
                                        <a className={s.ln}>linkedin</a>
                                    </Link>
                                </li>
                            </ul>
                        </li>
                        <li className={`${s.logoColumn} col-lg-3 col-md-3 offset-lg-1 offset-md-1 col-sm-6 col-6`}>
                            <div>
                                <p className={s.columnLabel}>Tjänster</p>
                            </div>
                            <div>
                                <div>
                                    <a href={'/forsakringsservice'}>
                                        <span className={s.columnItem}>Försäkringsservice</span>
                                    </a>
                                </div>
                                <div>
                                    <Link href="/skadeservice">
                                        <a>
                                            <span className={s.columnItem}>Skadeservice</span>
                                        </a>
                                    </Link>
                                </div>
                                <div>
                                    <span className={s.columnItem}>Försäkringsutmanaren
                                    </span>
                                </div>
                                <div>
                                    <a href={'/minasidor'}>
                                        <span className={s.columnItem}>MinaSidor</span>
                                    </a>
                                </div>
                            </div>
                        </li>
                        <li className={`${s.logoColumn} col-lg-3 col-md-3 offset-md-1 offset-lg-0 col-sm-6 col-6`}>
                            <div>
                                <p className={s.columnLabel}>Företaget</p>
                            </div>
                            <div className={s.columnItems}>
                                <div>
                                    <Link href="/omoss">
                                        <a className={s.columnItem}>
                                            Om oss
                                        </a>
                                    </Link>
                                </div>
                                <div>
                                    <Link href="/forsakringsguiden">
                                        <a className={s.columnItem}>
                                            Försäkringsguiden
                                        </a>
                                    </Link>
                                </div>
                                <div>
                                    <Link href="/faq">
                                        <a className={s.columnItem}>
                                            FAQ
                                        </a>
                                    </Link>
                                </div>
                                <div>
                                    <a href={'/support'}>
                                        <span className={s.columnItem}>Support</span>
                                    </a>
                                </div>
                                <div>
                                    <a href={'/kontaktaoss'}>
                                        <span className={s.columnItem}>Kontakta oss</span>
                                    </a>
                                </div>
                            </div>
                        </li>
                    </ul>
                    <DeviderRow />
                    <div className={`${s.termsAndLicenseRow} row`}>
                        <div className={`${s.ARRContainer} col-12 col-lg-7 order-2 order-lg-1`}>
                            <span>
                                © 2020 Nya Försäkringar Sverige AB, All Rights Reserved.
                            </span>
                        </div>
                        <ul className={`${s.licenseContainer} col-12 col-lg-5 order-1 order-lg-2 d-lg-flex justify-content-lg-end`}>
                            <li>
                                <Link href="/">
                                    <a>Terms</a>
                                </Link>
                            </li>
                            <li>
                                <Link href="/">
                                    <a>Privacy</a>
                                </Link>
                            </li>
                            <li>
                                <Link href="/">
                                    <a>License</a>
                                </Link>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>
    )
}

export default FooterBlock;
