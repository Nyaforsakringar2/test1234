import { useState } from 'react';
import { Accordion, Card } from 'react-bootstrap';
import * as s from '../../styles/FAQ/FaqInfo.module.css';

const FaqInfo = () => {
    const [activeItemIndex, setActiveItemIndex] = useState();
    const onHeaderClick = (selectedIndex) => {
        if (selectedIndex === activeItemIndex) {
            setActiveItemIndex(null);
        } else {
            setActiveItemIndex(selectedIndex);
        }
    };

    return (
        <section className={s.sectionContainer}>
            <h1>
                Frequently Asked Questions
            </h1>
            <div className={s.accordionContainer}>
                <Accordion className={s.accordion}>
                    <Card className={s.cardHeader}>
                        <Accordion.Toggle
                            className={`${s.toggleItem} ${activeItemIndex === 0 ? s.active : ''}`}
                            as={Card.Header}
                            eventKey="0"
                            onClick={() => onHeaderClick(0)}>
                            What information do I need to create an account?
                        </Accordion.Toggle>
                        <Accordion.Collapse className={s.collapseItem} eventKey="0">
                            <Card.Body>
                                Hello! I'm the body
                            </Card.Body>
                        </Accordion.Collapse>
                    </Card>
                    <Card className={s.cardHeader}>
                        <Accordion.Toggle
                            className={`${s.toggleItem} ${activeItemIndex === 1 ? s.active : ''}`}
                            as={Card.Header}
                            eventKey="1"
                            onClick={() => onHeaderClick(1)}>
                            How do I set up my Round-Ups?
                        </Accordion.Toggle>
                        <Accordion.Collapse className={s.collapseItem} eventKey="1">
                            <Card.Body>
                                Hello! I'm another body
                            </Card.Body>
                        </Accordion.Collapse>
                    </Card>
                    <Card className={s.cardHeader}>
                        <Accordion.Toggle
                            className={`${s.toggleItem} ${activeItemIndex === 2 ? s.active : ''}`}
                            as={Card.Header}
                            eventKey="2"
                            onClick={() => onHeaderClick(2)}>
                            How do I make a Quick Buy?
                        </Accordion.Toggle>
                        <Accordion.Collapse className={s.collapseItem} eventKey="2">
                            <Card.Body>
                                Hello! I'm another body
                            </Card.Body>
                        </Accordion.Collapse>
                    </Card>
                    <Card className={s.cardHeader}>
                        <Accordion.Toggle
                            className={`${s.toggleItem} ${activeItemIndex === 3 ? s.active : ''}`}
                            as={Card.Header}
                            eventKey="3"
                            onClick={() => onHeaderClick(3)}>
                            How do I see all my investments?                        </Accordion.Toggle>
                        <Accordion.Collapse className={s.collapseItem} eventKey="3">
                            <Card.Body>
                                Far far away, behind the word mountains, far from the countries Vokalia and Consonantia,
                                there live the blind texts. Separated they live in Bookmarksgrove right at the coast of
                                the Semantics, a large language ocean.  Far far away, behind the word mountains.
                                Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.
                            </Card.Body>
                        </Accordion.Collapse>
                    </Card>
                    <Card className={s.cardHeader}>
                        <Accordion.Toggle
                            className={`${s.toggleItem} ${activeItemIndex === 4 ? s.active : ''}`}
                            as={Card.Header}
                            eventKey="4"
                            onClick={() => onHeaderClick(4)}>
                            How can I add a statement of work to my contract?
                        </Accordion.Toggle>
                        <Accordion.Collapse className={s.collapseItem} eventKey="4">
                            <Card.Body>
                                Hello! I'm another body
                            </Card.Body>
                        </Accordion.Collapse>
                    </Card>
                    <Card className={s.cardHeader}>
                        <Accordion.Toggle
                            className={`${s.toggleItem} ${activeItemIndex === 5 ? s.active : ''}`}
                            as={Card.Header}
                            eventKey="5"
                            onClick={() => onHeaderClick(5)}>
                            I can't see the payment form on my contractor's invoice?
                        </Accordion.Toggle>
                        <Accordion.Collapse className={s.collapseItem} eventKey="5">
                            <Card.Body>
                                Hello! I'm another body
                            </Card.Body>
                        </Accordion.Collapse>
                    </Card>
                    <Card className={s.cardHeader}>
                        <Accordion.Toggle
                            className={`${s.toggleItem} ${activeItemIndex === 6 ? s.active : ''}`}
                            as={Card.Header}
                            eventKey="6"
                            onClick={() => onHeaderClick(6)}>
                            How can I edit my standard work contracts?
                        </Accordion.Toggle>
                        <Accordion.Collapse className={s.collapseItem} eventKey="6">
                            <Card.Body>
                                Hello! I'm another body
                            </Card.Body>
                        </Accordion.Collapse>
                    </Card>
                </Accordion>
            </div>
        </section>
    )
};

export default FaqInfo;
