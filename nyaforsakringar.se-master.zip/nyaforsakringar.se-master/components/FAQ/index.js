import FaqInfo from './FaqInfo';

export {
    FaqInfo
};
