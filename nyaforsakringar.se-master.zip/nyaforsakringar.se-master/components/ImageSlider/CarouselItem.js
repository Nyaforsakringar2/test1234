import React from 'react';
import * as s from '../../styles/ImageSlider/CarouselItem.module.css';

const CarouselItem = ({imgSrc, title}) => {
    return (
        <div className={s.container}>
            <div className={s.imageContainer}>
                <img src={imgSrc} className={s.img} />
            </div>
            <div className={s.descriptionContainer}>
                <h2 className={s.description}> {title} </h2>
            </div>
            <div className={s.readMoreContainer}>
                <a href={'/readmore'}>
                    <span className={s.readMoreText}>
                        READ MORE >
                    </span>
                </a>
            </div>
        </div>
    )
}

export default CarouselItem;
