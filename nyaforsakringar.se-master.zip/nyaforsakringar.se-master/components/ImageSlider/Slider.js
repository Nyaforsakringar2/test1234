import React, { useState } from 'react'
import CarouselItem from './CarouselItem';
import * as s from '../../styles/ImageSlider/Slider.module.css';

const Slider = (props) => {
    return (
        <div className={s.mainContainer}>
            <CarouselItem imgSrc={'/images/landing/carousel_1.png'} title={"Värt att veta på resan"}/>
            <CarouselItem imgSrc={'/images/landing/carousel_2.png'} title={"Corona viruset"}/>
            <CarouselItem imgSrc={'/images/landing/carousel_1.png'} title={"Allt om bilförsäkring"}/>
            <style jsx>{
                `/* width */
                ::-webkit-scrollbar {
                  height: 8px;
                }
                
                /* Track */
                ::-webkit-scrollbar-track {
                   box-shadow: inset 0 0 2px #F5FAFF; 
                   background: #F5FAFF;
                    border-radius: 30px;
                }
                 
                /* Handle */
                ::-webkit-scrollbar-thumb {
                  background: #4091F7; 
                }
                
                /* Handle on hover */
                ::-webkit-scrollbar-thumb:hover {
                  background: #4091F7; 
                }`
            }</style>
        </div>
    )
}

export default Slider
