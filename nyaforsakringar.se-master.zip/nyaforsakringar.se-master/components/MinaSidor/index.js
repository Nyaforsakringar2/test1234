import React from 'react';
import * as s from '../../styles/MinaSidor/MinaSidor.module.css';
import Item from './Item';
import Header from '../Header';

const MinaSidor = () => {
    return (
        <div className={s.container}>
            <Header />
            <div className={s.titleBlock}>
                <div className={s.titleContainer}>
                    <h1>
                        Välkommen, Username
                    </h1>
                    <span>
                        Här kan du se, ändra och använda dina försäkringar.
                    </span>
                </div>
            </div>
            <div className={s.empty} />
            <div className={s.content}>
                <div className={s.itemsContainer}>
                    <Item
                        href='/skadeanmalan'
                        withArrow
                        imgSrc={'/images/minaSidor/icon-search.png'}
                    >
                        <h4>Jämför pris & innehåll</h4>
                        <span>Hos alla försäkringsbolag.</span>
                    </Item>
                    <Item
                        withArrow
                        imgSrc={'/images/minaSidor/icon-2.png'}
                    >
                        <h4>Jämför pris & innehåll</h4>
                        <span>Hos alla försäkringsbolag.</span>
                    </Item>
                    <Item
                        withArrow
                        imgSrc={'/images/minaSidor/icon-2.png'}
                    >
                        <h4>Jämför pris & innehåll</h4>
                        <span>Hos alla försäkringsbolag.</span>
                    </Item>
                    <Item
                        withArrow
                        imgSrc={'/images/minaSidor/icon-2.png'}
                    >
                        <h4>Jämför pris & innehåll</h4>
                        <span>Hos alla försäkringsbolag.</span>
                    </Item>
                    <Item
                        withArrow
                        imgSrc={'/images/minaSidor/icon-2.png'}
                    >
                        <h4>Jämför pris & innehåll</h4>
                        <span>Hos alla försäkringsbolag.</span>
                    </Item>
                    <Item
                        withArrow
                        imgSrc={'/images/minaSidor/icon-2.png'}
                    >
                        <h4>Jämför pris & innehåll</h4>
                        <span>Hos alla försäkringsbolag.</span>
                    </Item>
                </div>
                <div className={s.informationContainer}>
                    <div className={s.informationHeaderContainer}>
                        <h4>
                            Övrig information om din försäkring
                        </h4>
                    </div>
                    <div className={s.informationItemsContainer}>
                        <Item
                            marginRight
                            imgSrc={'/images/minaSidor/icon-search.png'}
                        >
                            <h4>Jämför pris & innehåll</h4>
                            <span>Hos alla försäkringsbolag.</span>
                        </Item>
                        <Item
                            marginLeft
                            imgSrc={'/images/minaSidor/icon-2.png'}
                        >
                            <h4>Jämför pris & innehåll</h4>
                            <span>Hos alla försäkringsbolag.</span>
                        </Item>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default MinaSidor;
