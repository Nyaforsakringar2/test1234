import React from "react";
import * as s from '../../styles/MinaSidor/MinaSidor.module.css';
import Router from 'next/router'

const Item = (props) => {
    let {imgSrc, withArrow, children, href="/"} = props;
    return (
        <div
            onClick={() => {
                Router.push(href);
            }}
            className={ s.itemContainer}>
            <div className={s.itemImgContainer}>
                <img src={imgSrc} className={s.icon}/>
            </div>
            <div className={s.itemDescriptionContainer}>
                {children}
            </div>
            {
                withArrow && (<div className={s.itemArrow}> <img src={'/images/minaSidor/arrow.png'}/> </div>)
            }
        </div>
    )
}
export default Item;
