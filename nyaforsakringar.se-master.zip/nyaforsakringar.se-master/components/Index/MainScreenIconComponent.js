import React from 'react';
import * as s from '../../styles/Index/MainScreenIconComponent.module.css';

const MainScreenIconComponent = ({imgUrl, buttonTitle, imageClassContainer, imageClassName}) => (
    <div className={`${s.iconContainer} ${imageClassContainer}`}>
        <div className={`${s.imageContainer} ${imageClassName}`}>
            <span className={s.imgStyle}/>
        </div>
        <div className={s.buttonContainer}>
            <div className={s.button}>
                <span className={s.buttonText}>{buttonTitle}</span>
            </div>
        </div>
    </div>
)

export default MainScreenIconComponent;
