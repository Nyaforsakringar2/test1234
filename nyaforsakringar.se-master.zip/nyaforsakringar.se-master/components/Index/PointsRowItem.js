import React from 'react';
import * as s from '../../styles/Index/PointsRowItem.module.css';

const PointsRowItem = ({description, number, header, color}) => {
    let className = number == '1' ? s.mainContainer + ' ' + s.first
        : number == '3' ? s.mainContainer + ' ' + s.last
            : s.mainContainer
    return (
        <div className={className}>
            <div className={s.numberSectionContainer}>
                <div className={s.headerContainer}>
                    <h3> {header} </h3>
                </div>
                <div className={color && color == 'orange' ? s.numberContainerOrange : s.numberContainer}>
                    <p className={color && color == 'orange' ? s.numberTextOrange : s.numberText}>
                        {number}
                    </p>
                </div>
            </div>
            <div>
                <p className={s.descriptionText}>
                    {description}
                </p>
            </div>
        </div>
    )
}

export default PointsRowItem;
