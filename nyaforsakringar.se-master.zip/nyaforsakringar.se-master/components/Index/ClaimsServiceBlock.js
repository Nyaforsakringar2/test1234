import React, {Component} from 'react';
import * as s from '../../styles/Index/ClaimsServiceBlock.module.css';
import Link from 'next/link';

class ClaimsServiceBlock extends Component {

    render() {
        return (
            <section className={s.mainContainer}>
                <header className="">
                    <div className={s.titleContainer}>
                        <span className={`${s.stepPointNumber} flex-grow-0 flex-shrink-0`}>3</span>
                        <h1 className={`${s.claimsServiceBlockTitle} flex-grow-1 flex-shrink-1`}>
                            <Link href="/skadeservice">
                                <a>
                                    Skadeservice
                                </a>
                            </Link>
                        </h1>
                    </div>
                    <p className="align-self-center">
                        Vi på Nya Försäkringar rekommenderar inte bara  en försäkring, vi finns till även när skadan är framme.
                        Med vår skadeservice missar du ingen ersättning och får hjälp av en expert som alltid är på din sida.
                        Vi samlar informationen, dokumenterar, korresponderar, företräder och  tar hand om  telefonköerna.
                    </p>
                </header>
                <ul className={`${s.highlights} row`}>
                    <li className="col-12 col-lg-4">
                        <span></span>
                        <p>
                            Uppdaterat försäkringsskydd och pris varje år.
                        </p>
                    </li>
                    <li className="col-12 col-lg-4">
                        <span></span>
                        <p>
                            Vi tar ansvar hela vägen.
                        </p>
                    </li>
                    <li className="col-12 col-lg-4">
                        <span></span>
                        <p>
                            Jämföra alla bolag.
                        </p>
                    </li>
                </ul>
            </section>
        )
    }
}

export default ClaimsServiceBlock;
