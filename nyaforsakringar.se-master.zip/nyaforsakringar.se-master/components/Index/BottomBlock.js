import React, {useState} from 'react';
import Link from 'next/link';
import * as s from '../../styles/Index/BottomBlock.module.css';
import Button  from '../shared/Button';
import Slider from '../ImageSlider/Slider';

const BottomBlock = () => {

    return (
        <section className={s.mainContainer}>
            <div className={s.imageContentContainer}>
                <div className={s.imageStyle}>
                    {/*<div className={s.imageLogo}></div>*/}
                </div>
                <div className={s.imageDescriptionContainer}>
                    <div className={s.descriptionHeaderContainer}>
                        <h1 className={s.header}>
                            Upptäck skillnaden.
                        </h1>
                    </div>
                    <div className={s.descriptionContainer}>
                        <p className={s.description}>
                            Trött på att försäkringsbolaget höjer premien?
                            Vi erbjuder Sveriges mest prisvärda försäkringar och skadeservice när olyckan väl är framme.
                            Genom att ta ansvar hela vägen för att tillvarata våra kunders intressen tar vi bort allt
                            det där tråkiga med försäkringar, som försäkringar borde fungera helt enkelt. Alltid på din sida.
                        </p>
                    </div>
                    <div className={s.buttonContainer}>
                        <Link href="/jamfor">
                            <a>
                                <Button title="Utmana dina försäkringar" />
                            </a>
                        </Link>
                    </div>
                </div>
            </div>
            <div className={s.headerSection}>
                <div className={s.column}>
                    <div className={s.headerContainer}>
                        <h1 className={s.header}>
                            Försäkringsguiden
                        </h1>
                    </div>
                </div>
                <div className={s.column}>
                    <div className={s.descriptionContainer}>
                        <p className={s.description}>
                            Vi ger dig trygghet utan att du får betala för mycket för den, genom att jämföra med hjälp
                            av smarta digitala lösningar, erfaren personal och digitala verktyg för att underlätta ditt val av försäkring.
                        </p>
                    </div>
                </div>
            </div>
            <div className={s.sliderWrapper}>
                <Slider />
            </div>
        </section>
    )
}
export default BottomBlock;
