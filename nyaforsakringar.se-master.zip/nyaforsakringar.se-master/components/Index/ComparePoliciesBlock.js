import React, {Component} from 'react';
import Link from 'next/link';
import Typewriter from 'typewriter-effect';
import * as s from '../../styles/Index/ComparePoliciesBlock.module.css';

class ComparePoliciesBlock extends Component {
    state = {
        typewriterWords: ['försäkringar.', 'priser.', 'försäkringsbolag.', 'villkor.', 'självrisker.']
    };

    typewriter() {
        return <Typewriter
          options={{
              strings: this.state.typewriterWords,
              autoStart: true,
              loop: true
          }}
        />
    }

    render() {
        return (
            <section className={s.mainContainer}>
                <div className={s.mainContainerInner}>
                    <header>
                        <span>1</span>
                        <h1>
                            <Link href="/">
                                <a className={s.typewriterContainer}>
                                    Jämför dina
                                    { this.typewriter() }
                                </a>
                            </Link>
                        </h1>
                    </header>
                    <ul className={`${s.policiesList} row`}>
                        <li className="col-6 col-lg-3">
                            <span></span>
                            <p>
                                Bil
                            </p>
                        </li>
                        <li className="col-6 col-lg-3">
                            <span></span>
                            <p>
                                Villa
                            </p>
                        </li>
                        <li className="col-6 col-lg-3">
                            <span></span>
                            <p>
                                Fritidshus
                            </p>
                        </li>
                        <li className="col-6 col-lg-3">
                            <span></span>
                            <p>
                                MC
                            </p>
                        </li>
                        <li className="col-6 col-lg-3">
                            <span></span>
                            <p>
                                Sjukvård
                            </p>
                        </li>
                        <li className="col-6 col-lg-3">
                            <span></span>
                            <p>
                                Barn
                            </p>
                        </li>
                        <li className="col-6 col-lg-3">
                            <span></span>
                            <p>
                                Olycksfall
                            </p>
                        </li>
                        <li className="col-6 col-lg-3">
                            <span></span>
                            <p>
                                Djur
                            </p>
                        </li>
                    </ul>
                    <span className={s.backgroundOverlay}></span>
                </div>
            </section>
        )
    }
}

export default ComparePoliciesBlock;
