import React from 'react';
import styles from '../../styles/Index/Banner.module.css';
import { Button } from './index';

const Banner = () => {
    return (
        <section className={styles.videoContainer}>
          <video playsInline autoPlay muted loop className={styles.bannerVideo}>
            <source src="/videos/landing-banner-video.mp4" type="video/mp4" />
          </video>
          <div className={`${styles.videoTextContainer} container-fluid h-100`}>
            <div className="row">
              <div className="col-8 offset-1">

                <div className="d-flex h-100 align-items-top">
                  <div className="w-100 text-white">
                    <h1 className={`${styles.imgTextTitle} display-2`}>
                      Jämför alla försäkringsbolag.
                    </h1>
                    <p className={styles.imgTextSubtitle}>
                      Varje år förnyas svenskars försäkringar med höjda premier utan att försäkringsbolagets
                      risk har förändrats. Sänk dina kostnader och säkerställ att du är rätt försäkrad med
                      vår pris och villkorsjämförelse. Skaffa dig en personlig rådgivare redan idag.
                    </p>
                    <Button title={"Få ett prisförslag"}/>
                    {/*<p className="lead mb-0">With HTML5 Video and Bootstrap 4</p>*/}
                  </div>
                </div>

              </div>
            </div>
          </div>
        </section>
    )
};

export default Banner;
