import Header from '../shared/Header';
import ComparePoliciesBlock from './ComparePoliciesBlock';
import VideoBlock from './VideoBlock';
import DeviderRow from '../shared/DeviderRow';
import ClaimsServiceBlock from './ClaimsServiceBlock';
import PointsRowItem from './PointsRowItem';
import IconsBlock from './IconsBlock';
import BottomBlock from './BottomBlock';
import PreFooter from '../shared/PreFooter';
import FooterBlock from '../shared/FooterBlock';
import Button from '../shared/Button';

export {
    Header,
    ComparePoliciesBlock,
    VideoBlock,
    DeviderRow,
    ClaimsServiceBlock,
    PointsRowItem,
    IconsBlock,
    BottomBlock,
    PreFooter,
    FooterBlock,
    Button
};
