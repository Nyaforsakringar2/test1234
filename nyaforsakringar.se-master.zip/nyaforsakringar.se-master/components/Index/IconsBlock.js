import React from 'react';
import MainScreenIconComponent from './MainScreenIconComponent';
import Button from '../shared/Button';
import * as s from '../../styles/Index/IconsBlock.module.css';

const IconsBlock = () => {
    let iconComponents = ['Bil', 'Hem', 'Fritidshus', 'Båt', 'Person', 'Husbil', 'Moped', 'Motorcykel'];

    iconComponents = iconComponents.map((title, index) =>
        <MainScreenIconComponent
          key={index}
          buttonTitle={title}
          imageClassContainer={s.iconComponentContainer}
          imageClassName={s.iconComponentImg}
        />
    );

    return (
        <section className={s.mainContainer}>
            <span className={s.backgroundStartHelper}></span>
            <div className={s.contentWrapper}>
                <div className={s.headerSection}>
                    <div className={s.column}>
                        <div className={s.titleContainer}>
                            <p className={s.titleText}>
                                jämför
                            </p>
                        </div>
                        <div>
                            <h1 className={s.headerText}>
                                Försäkringsutmanaren
                            </h1>
                        </div>
                    </div>
                    <div className={s.column}>
                        <div className={s.descriptionWrapper}>
                            <p className={s.descriptionText}>
                                Nya Försäkringar hjälper dig att spara tid och pengar – smart, enkelt och
                                blixtsnabbt. Boka en kostnadsfri rådgivning med en av våra
                                försäkringsexperter.
                            </p>
                        </div>
                        <div className={s.buttonWrapper}>
                            <Button title={'Få ett prisförslag'}/>
                        </div>
                    </div>
                </div>
                <div className={s.iconsSection}>
                    { iconComponents }
                </div>
                {/*<div className={s.visaButtonContainer}>*/}
                {/*    <div className={s.visaButton}>*/}
                {/*        <span className={s.visaButtonText}> Visa fler </span>*/}
                {/*    </div>*/}
                {/*</div>*/}
            </div>
            <span className={s.backgroundEndHelper}></span>
        </section>
    )
}
export default IconsBlock;
