import React, {Component} from 'react';
import Link from 'next/link';
import * as s from '../../styles/Index/VideoBlock.module.css';
import DeviderRow from '../shared/DeviderRow';

class VideoBlock extends Component {

    render() {
        return (
            <section className={s.contentWrapper}>
                <header className={`row m-0 align-items-start ${s.videoBlockHeader}`}>
                    <div className="col-12 col-lg-8 col-xl-7 offset-xl-1 d-flex align-items-center pb-sm-3">
                        <span className={`${s.stepPointNumber} flex-grow-0 flex-shrink-0`}>2</span>
                        <h1 className={`${s.videoBlockTitle} flex-grow-1 flex-shrink-1 mt-3 mt-sm-0 mb-3 mb-sm-0`}>
                            <Link href="/forsakringsservice">
                                <a>
                                    Årlig Försäkringkoll.
                                </a>
                            </Link>
                        </h1>
                    </div>
                    <p className="col-lg-4 pt-xl-4 align-self-center">
                        Varje år uppdaterar vi både innehållet i din försäkring efter dina behov och söker efter bästa
                        pris på marknaden. Detta gör vi automatiskt och skickar en försäkringskoll du kan göra digitalt
                        eller personligen med någon av våra rådgivare.
                        Du missar aldrig en uppdaterad försäkring, vi gör det åt dig.
                    </p>
                </header>
                <div className={s.videoWrapper}>
                    <div className={s.videoContainer}>
                        <video playsInline muted controls poster="/images/landing/video-img.png" className={s.video}>
                            <source src="/videos/landing-banner-video.mp4" type="video/mp4"/>
                        </video>
                        {/*<div className={s.playButtonWrapper}>*/}
                        {/*    <div className={s.playButton}>*/}
                        {/*        <img src={'/images/play-button.png'} className={s.playButtonStyle}/>*/}
                        {/*        <span className={s.buttonText}> Play video</span>*/}
                        {/*    </div>*/}
                        {/*</div>*/}
                    </div>
                    <DeviderRow className={s.videoDivider} />
                    <div className={s.videoDescriptionRow}>
                        <ul className="row m-0">
                            <li className="col-12 col-sm-6">
                                <div>
                                    <h2 className={s.itemTitleText}>
                                        Rätt Försäkrad.
                                    </h2>
                                </div>
                                <div>
                                    <p className={s.itemDescriptionText}>
                                        Med vår enkla försäkringsutmanare jämför du enkelt dina villkor och
                                        priser. Vi tar fram rätt försäkring för dina behov och gör det enkelt
                                        för dig att jämföra mot din gamla försäkring. Att förstå
                                        försäkringsvillkor har aldrig varit enklare.
                                    </p>
                                </div>
                            </li>
                            <li className="col-12 col-sm-6">
                                <div>
                                    <h2 className={s.itemTitleText+" "+s.textBlue}>
                                        Rätt Pris.
                                    </h2>
                                </div>
                                <div>
                                    <p className={s.itemDescriptionText}>
                                        Vi söker efter försäkring hos ​alla ​försäkringsbolag genom att inhämta priser från alla bolag i ett knapptryck. Smart, enkelt och blixtsnabbt. Sveriges enda försäkringsförmedlare som jämför alla priser på din försäkring.
                                    </p>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </section>
        )
    }
}

export default VideoBlock;
