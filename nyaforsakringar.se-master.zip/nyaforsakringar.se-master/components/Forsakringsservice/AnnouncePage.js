import * as s from '../../styles/Forsakringsservice/AnnouncePage.module.css';
import Button from '../shared/Button';
import DeviderRow from '../shared/DeviderRow';

const AnnouncePage = () => {
    return (
        <section className={s.sectionContainer}>
            <header>
                <DeviderRow className={s.divider} />
                    <h1>Vi jämför dina försäkringar.</h1>
                    <p>
                      Att jämföra försäkringar kan vara krångligt, det vill vi ändra på.
                      I dagsläget betalar vi i Sverige för mycket för sina försäkringar och många blir besvikna när försäkringen inte motsvarar förväntningarna.
                      Vi ser därför till att du blir rätt försäkrad till rätt pris.
                      Att jämföra försäkringar har aldrig varit enklare, bli kund redan idag och se hur mycket du kan spara.
                      Vi tar hand om det tråkiga med att byta och säga upp din gamla försäkring.
                    </p>
                    <Button className={s.button} innerClassName={s.buttonInner} title="jämför" style="blue" />
            </header>
        </section>
    )
};
export default AnnouncePage;
