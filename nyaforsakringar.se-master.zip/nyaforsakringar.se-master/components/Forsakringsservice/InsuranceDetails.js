import React, {useState} from 'react';
import * as s from '../../styles/Forsakringsservice/InsuranceDetails.module.css';
import expandCollapseCSSPlain from '../../styles/shared/expandCollapse'
import Button from '../shared/Button';
import DeviderRow from '../shared/DeviderRow';
import Carousel from 'react-bootstrap/Carousel';
import ExpandCollapse from 'react-expand-collapse';

const InsuranceDetails = () => {
    const [index, setIndex] = useState(0);
    const handleSelect = (selectedIndex, e) => {
        if (selectedIndex === index) return;
        setIndex(selectedIndex);
    };
    const EXPAND_COLLAPSE_OPTIONS = {
        previewHeight: '72px',
        collapseText: 'MINDRE',
        expandText: 'MER',
    };

    return (
        <section className={s.sectionContainer}>
            <DeviderRow className={s.divider}/>
            <div id="insuranceDetailsCarousel">
                <h1>
                    Försäkringar
                </h1>
                <ul className={`${s.carouselIndicators} d-none d-md-flex`}>
                    <li key="0" onClick={() => handleSelect(0)} className={index === 0 ? s.active : ''}>
                        Fordon
                    </li>
                    <li key="1" onClick={() => handleSelect(1)} className={index === 1 ? s.active : ''}>
                        Hem & Villa
                    </li>
                    <li key="2" onClick={() => handleSelect(2)} className={index === 2 ? s.active : ''}>
                        Fritidshus
                    </li>
                    <li key="3" onClick={() => handleSelect(3)} className={index === 3 ? s.active : ''}>
                        Personförsäkringar
                    </li>
                </ul>
                <Carousel
                    controls={false}
                    indicators={false}
                    activeIndex={index}
                    onSelect={handleSelect}>
                    <Carousel.Item className={s.carouselItem}>
                        <div className={`${s.Container} row flex-column flex-md-row`}>
                            <div className={`${s.picture} col-12 col-md-6`}>
                                <img src="/images/forsakringsservice/forsakringar-slider-1.png"/>
                            </div>
                            <div className={`${s.descriptionContainer} col-12 col-md-6 text-center text-md-left`}>
                                <h2>
                                    Bil
                                </h2>
                                <ExpandCollapse {...EXPAND_COLLAPSE_OPTIONS} className={`${s.expandCollapse} d-sm-none`}>
                                    <p>
                                        Vi söker efter försäkring hos ​alla ​försäkringsbolag genom att inhämta priser från
                                        alla bolag i ett knapptryck.
                                    </p>
                                </ExpandCollapse>
                                <p className="d-none d-sm-block">
                                    Vi söker efter försäkring hos ​alla ​försäkringsbolag genom att inhämta priser från
                                    alla bolag i ett knapptryck.
                                </p>
                                <div className={s.linksContainer}>
                                    <Button
                                        title="Kostnadsfri rådgivning"
                                        style="blue"
                                        className={s.button}
                                        titleClassName={s.buttonTitle} />
                                    <a href="" className={s.readmore}>Läs mer</a>
                                </div>
                            </div>
                        </div>
                    </Carousel.Item>
                    <Carousel.Item className={s.carouselItem}>
                        <div className={`${s.Container} row flex-column flex-md-row`}>
                            <div className={`${s.picture} col-12 col-md-6`}>
                                <img src="/images/forsakringsservice/forsakringar-slider-2.png"/>
                            </div>
                            <div className={`${s.descriptionContainer} col-12 col-md-6 text-center text-md-left`}>
                                <h2>
                                    Hem & Villa
                                </h2>
                                <ExpandCollapse {...EXPAND_COLLAPSE_OPTIONS} className={`${s.expandCollapse} d-sm-none`}>
                                    <p>
                                        Att ha rätt försäkring till en av de största investeringarna vi gör kan vara
                                        avgörande i en krissituation.
                                        Vi rådgiver därför efter dina förutsättningar, olika villkor passa olika bra
                                        beroende på förutsättningar.
                                        Har du pool eller inga kvalitetsdokument på badrummet, det finns en försäkrings som
                                        passar alla men alla försäkringar passar inte alla.
                                        Med vår erfarenhet, smarta digitala verktyg, och villkordatabas tar vi fram rätt
                                        försäkring till rätt pris.
                                    </p>
                                </ExpandCollapse>
                                <p className="d-none d-sm-block">
                                    Att ha rätt försäkring till en av de största investeringarna vi gör kan vara
                                    avgörande i en krissituation.
                                    Vi rådgiver därför efter dina förutsättningar, olika villkor passa olika bra
                                    beroende på förutsättningar.
                                    Har du pool eller inga kvalitetsdokument på badrummet, det finns en försäkrings som
                                    passar alla men alla försäkringar passar inte alla.
                                    Med vår erfarenhet, smarta digitala verktyg, och villkordatabas tar vi fram rätt
                                    försäkring till rätt pris.
                                </p>
                                <div className={s.linksContainer}>
                                    <Button
                                        title="Kostnadsfri rådgivning"
                                        style="blue"
                                        className={s.button}
                                        titleClassName={s.buttonTitle} />
                                    <a href="" className={s.readmore}>Läs mer</a>
                                </div>
                            </div>
                        </div>
                    </Carousel.Item>
                    <Carousel.Item className={s.carouselItem}>
                        <div className={`${s.Container} row flex-column flex-md-row`}>
                            <div className={`${s.picture} col-12 col-md-6`}>
                                <img src="/images/forsakringsservice/forsakringar-slider-3.png"/>
                            </div>
                            <div className={`${s.descriptionContainer} col-12 col-md-6 text-center text-md-left`}>
                                <h2>
                                    Fritidshus
                                </h2>
                                <ExpandCollapse {...EXPAND_COLLAPSE_OPTIONS} className={`${s.expandCollapse} d-sm-none`}>
                                    <p>
                                        Här kan du läsa mer om allt från fritidshusförsäkringen, båten, fyrhjulingen eller
                                        snöskotern. Det kan skilja mycket i pris men även villkoren kan ha skillnader
                                        framförallt när det gäller din byggnadsförsäkring. Vi på Nya försäkringar försäkrar
                                        allt även din fritid. Läs mer om detta på länken nedan eller få en kostnadsfri rådgivning.
                                    </p>
                                </ExpandCollapse>
                                <p className="d-none d-sm-block">
                                    Här kan du läsa mer om allt från fritidshusförsäkringen, båten, fyrhjulingen eller
                                    snöskotern. Det kan skilja mycket i pris men även villkoren kan ha skillnader
                                    framförallt när det gäller din byggnadsförsäkring. Vi på Nya försäkringar försäkrar
                                    allt även din fritid. Läs mer om detta på länken nedan eller få en kostnadsfri rådgivning.
                                </p>
                                <div className={s.linksContainer}>
                                    <Button
                                        title="Kostnadsfri rådgivning"
                                        style="blue"
                                        className={s.button}
                                        titleClassName={s.buttonTitle} />
                                    <a href="" className={s.readmore}>Läs mer</a>
                                </div>
                            </div>
                        </div>
                    </Carousel.Item>
                    <Carousel.Item className={s.carouselItem}>
                        <div className={`${s.Container} row flex-column flex-md-row`}>
                            <div className={`${s.picture} col-12 col-md-6`}>
                                <img src="/images/forsakringsservice/forsakringar-slider-4.png"/>
                            </div>
                            <div className={`${s.descriptionContainer} col-12 col-md-6 text-center text-md-left`}>
                                <h2>
                                    Personförsäkringar
                                </h2>
                                <ExpandCollapse {...EXPAND_COLLAPSE_OPTIONS} className={`${s.expandCollapse} d-sm-none`}>
                                    <p>
                                        Personförsäkringar är bland det viktigaste skydd vi har om vi skulle råka ut för en
                                        olycka eller sjukdom. Villkoren är många, snarlika och det kan vara svårt att veta
                                        vad försäkringen innehåller. Vi samarbetar med endast ett försäkringsbolag när det
                                        gäller personförsäkringar där vi kvalitetskontrollerat såväl innehåll som skadehantering..
                                        Försäkra dig själv och din familj med sjukvård, olycksfall och barnförsäkringar frå Euro Accident.
                                    </p>
                                </ExpandCollapse>
                                <p className="d-none d-sm-block">
                                    Personförsäkringar är bland det viktigaste skydd vi har om vi skulle råka ut för en
                                    olycka eller sjukdom. Villkoren är många, snarlika och det kan vara svårt att veta
                                    vad försäkringen innehåller. Vi samarbetar med endast ett försäkringsbolag när det
                                    gäller personförsäkringar där vi kvalitetskontrollerat såväl innehåll som skadehantering..
                                    Försäkra dig själv och din familj med sjukvård, olycksfall och barnförsäkringar frå Euro Accident.
                                </p>
                                <div className={s.linksContainer}>
                                    <Button
                                        title="Kostnadsfri rådgivning"
                                        style="blue"
                                        className={s.button}
                                        titleClassName={s.buttonTitle} />
                                    <a href="" className={s.readmore}>Läs mer</a>
                                </div>
                            </div>
                        </div>
                    </Carousel.Item>
                </Carousel>
            </div>
            <style jsx>
                {expandCollapseCSSPlain}
            </style>
        </section>
    )
};

export default InsuranceDetails;
