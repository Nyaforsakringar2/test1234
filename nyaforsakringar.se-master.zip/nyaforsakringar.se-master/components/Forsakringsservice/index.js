import Hero from './Hero';
import CompareInfo from './CompareInfo';
import AnnouncePage from './AnnouncePage';
import InsuranceDetails from './InsuranceDetails';

export {
    Hero,
    CompareInfo,
    AnnouncePage,
    InsuranceDetails
};
