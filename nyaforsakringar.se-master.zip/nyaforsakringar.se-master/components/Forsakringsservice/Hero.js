import React from 'react';
import * as s from '../../styles/Forsakringsservice/Hero.module.css';
import Button from '../shared/Button';

const Hero = () => {
    return (
        <section className={s.sectionContainer}>
            <header>
                <h1>Rätt Försäkrad till Rätt Pris</h1>
                <Button
                  className={s.button}
                  innerClassName={s.buttonInner}
                  titleClassName={s.buttonTitle}
                  title="jämför nu" style="blue"
                />
            </header>
        </section>
    )
};

export default Hero;
