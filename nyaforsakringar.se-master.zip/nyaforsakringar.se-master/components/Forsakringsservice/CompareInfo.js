import React from 'react';
import * as s from '../../styles/Forsakringsservice/CompareInfo.module.css';

const CompareInfo = () => {
    return (
        <section className={s.sectionContainer}>
            <header>
              <h1>Hur jämför vi?</h1>
              <p>
                Försäkringar är den mest svårförståeliga produkt en vanlig konsument tar till sig, det vet vi.
                Därför jämför vi inte bara priser utan även innehållet i din försäkring på ett enkelt och lättförståeligt sätt.
                Prova du också.
              </p>
            </header>
            <ul className={`${s.compareOptions} row`}>
              <li className="col-12 col-md-6">
                <div className={s.compareOptionContainer}>
                  <h2>Jämföra alla bolag.</h2>
                  <p>
                    Vi ger dig tillgång till alla priser, villkor och försäkringar med en enda sökning.
                    Skaffa dig smarta försäkringar, vi anpassar försäkringens innehåll,
                    självrisker och pressar priset för att du ska få marknadens förmånligaste försäkring sett till dina behov.
                  </p>
                </div>
              </li>
              <li className="col-12 col-md-6">
                <div className={s.compareOptionContainer}>
                  <h2>Vi tar ansvar hela vägen.</h2>
                  <p>
                    Efter det att vi hittat rätt försäkring till dig ser vi till att du får rätt ersättning med vår
                    skadeservice som ingår till alla våra kunder. Du slipper pappersarbetet, läsa försäkringsvillkoren
                    och kan känna dig trygg med att ha någon alltid på din sida. Med personlig service när du önskar
                    och möjligheten att uträtta dina ärenden digitalt.
                  </p>
                </div>
              </li>
              <li className="col-12 col-md-6 mb-0">
                <div className={s.compareOptionContainer}>
                  <h2>Uppdaterat försäkringsskydd och pris varje år.</h2>
                  <p>
                    Varje år gör vi en ny försäkringsgenomgång med våra kunder, den kan du välja få digitalt
                    eller prata personligen med någon av våra rådgivare. Vi ställer ett antal frågor för att uppdatera
                    ditt försäkringsbehov, pressar priserna och ger dig ett nytt erbjudande om försäkring.
                  </p>
                </div>
              </li>
              <li className="col-12 col-md-6 mb-0">
                <div className={s.compareOptionContainer}>
                  <h2>Mina sidor.</h2>
                  <p>
                    Här kan du utföra de flesta försäkringsärenden oavsett att du har flera försäkringsbolag
                    finns allting samlat via din kundprofil. Se och ändra dina försäkringar och anmäl skador
                    direkt i din dator eller mobiltelefon.
                  </p>
                </div>
              </li>
            </ul>
        </section>
    )
};

export default CompareInfo;
