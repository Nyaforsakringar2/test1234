import ContactInfo from './ContactInfo';
import PreFooter from './PreFooter';

export {
    ContactInfo,
    PreFooter
};
