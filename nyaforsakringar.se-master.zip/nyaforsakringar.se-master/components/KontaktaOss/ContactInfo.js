import * as s from '../../styles/KontaktaOss/ContactInfo.module.css';
import Button from '../shared/Button.js';

const ContactInfo = () => {
    return (
        <section className={s.sectionContainer}>
            <div className={s.sectionInnerContainer}>
                <header>
                    <h1>Kontakta oss</h1>
                    <p>Få support när som helst via chat, email, telefon eller social media.</p>
                </header>
                <ul className={s.contactInfoContainer}>
                    <li>
                        <a href="tel:040-121200">
                            <h2 className="tel">040-121200</h2>
                            <span>Ring oss.</span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <h2>Chatta med oss</h2>
                            <span>Över alla dina skadeförsäkringar.</span>
                        </a>
                    </li>
                    <li>
                        <a href="mailto:contact@nya.com">
                            <h2>Skicka epost</h2>
                            <span className="email">contact@nya.com</span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <h2>Skadeanmälan</h2>
                            <span>Se och anmäl skador.</span>
                        </a>
                    </li>
                    <li className={s.formContainer}>
                        <div className={s.formHeader}>
                            <div>
                                <h2>Bli uppringd</h2>
                                <span>Vi ringer upp dig när du önskar.</span>
                            </div>
                        </div>
                        <form>
                            <div>
                                <label htmlFor="name">
                                    Namn
                                </label>
                                <input id="name" name="name" type="text" placeholder="Enter your name"
                                       required="" autoFocus="" />
                            </div>
                            <div>
                                <label htmlFor="email">
                                    Email
                                </label>
                                <input id="email" name="email" type="email" placeholder="Enter your email" required="" />
                            </div>
                            <div>
                                <label htmlFor="subject">
                                    Ämne
                                </label>
                                <input id="subject" name="subject" type="text" placeholder="Subject" required="" />
                            </div>
                            <div>
                                <label htmlFor="tel">
                                    Ämne
                                </label>
                                <input id="tel" name="tel" type="tel" placeholder="Telefonnummer" required="" />
                            </div>
                            <div className="row">
                                 <div className={`${s.tos} col-12 col-sm-8 d-flex align-items-center`}>
                                     <input id="tos" name="tos" type="checkbox" />
                                     <label htmlFor="tos">
                                         I agree to the&nbsp;
                                         <a href="">Terms</a>
                                         &nbsp;and the&nbsp;
                                         <a href="">Privacy Policy</a>
                                     </label>
                                 </div>
                                 <div className="col-12 col-sm-4 text-right">
                                     <Button title="Send" className={s.button} />
                                 </div>
                            </div>
                        </form>
                    </li>
                </ul>
            </div>
        </section>
    )
};

export default ContactInfo;
