import * as s from '../../styles/KontaktaOss/PreFooter.module.css';

const PreFooter = () => {
    return (
        <section className={s.sectionContainer}>
            <div className={`${s.sectionInnerContainer} vcard`}>
                <h1>Företaget</h1>
                <p>
                    <span className="org d-block">
                        Nya Försäkringar Sverige AB </span>
                    Organisationsnummer
                    <span className="tel">  559227-9052</span>
                    <span className="adr d-block">
                        Minc |
                        <span className="street-address"> The Startup House of Malmö | Anckargripsgatan</span> ,
                        <span className="postal-code"> 211 19</span>
                        <span className="region"> Malmö</span>
                    </span>
                </p>
                <p>
                    Telefonnummer <span className="tel">040-121200</span>
                </p>
            </div>
        </section>
    )
};

export default PreFooter;
