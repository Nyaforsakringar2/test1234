import React from 'react';
import Button from '../shared/Button';
import * as s from '../../styles/Omoss/AnnouncePage.module.css';

const AnnouncePage = () => {
    return (
        <section className={`${s.sectionContainer} row flex-column-reverse flex-md-row`}>
            <div className={`${s.description} col-12 col-md-6 text-center text-md-left`}>
                <h1>
                    Nya ambitioner
                </h1>
                <p>
                    Våra ambition, förenkla användandet av försäkring, rätt försäkring till rätt pris och när skadan
                    väl är framme hjälper vi dig att få rätt ersättning. Att försäkringar är den mest svårförståeliga
                    produkt en vanlig konsument tar till sig, det vet vi. Därför jämför vi inte bara priser utan även
                    innehållet i din försäkring på ett enkelt och lättförståeligt sätt. Med vår försäkringsutmanare
                    jämför du lätt både pris och innehåll. Genom vår kostnadsfria rådgivning får du reda på hur
                    mycket du kan spara i försäkringskostnader och säkerställa att du bli rätt försäkrad.
                    Att jämföra försäkringar har aldrig varit enklare.
                </p>
                <Button title="Läs mer om oss" style="blue" />
            </div>
            <div className={`${s.picture} col-12 col-md-6`}>
                <img className="d-none d-md-block" src="/images/omoss/announce-pic.png" />
                <img className="d-md-none" src="/images/omoss/announce-pic-mb@2x.png" />
            </div>
        </section>
    )
};

export default AnnouncePage;
