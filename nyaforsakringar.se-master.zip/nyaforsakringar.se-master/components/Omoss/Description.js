import React from 'react';
import * as s from '../../styles/Omoss/Description.module.css';

const Description = () => {
    return (
        <section className={s.sectionContainer}>
            <h1>Vi</h1>
            <p className="text-center text-sm-left">
                Nya Försäkringar är skapat av rådgivare med erfarenhet från några av försäkringsbranschens största aktörer.
                Huvudsakligen har vi en  bakrund som rådgivare och skadehanterare vi har förmed,at tusentals försäkringar
                och fått en god insikt i de problem försäkringsbolagen inte kan lösa för konsumenten.
                Vi har sett utmaningar för dagens försäkringkunder att hitta rätt försäkring till rätt pris.
                Det vi ofta har mött är överdebiterade försäkringskunder, kunder som tycker att produkten är svår att
                jämföra och något man helst inte tar beslut kring för risken att göra fel.
                Man är ofta ovetandes att man betalar tusentals kronor mer än vad man behöver betala för sin
                försäkring och är  kvar hos samma försäkringsbolag år ut och år in.
                Vi tycker försäkringar är väldigt viktigt och att det ska fungera när det behövs.
                Vi tror däremot inte på att betala för mycket för sina försäkringar och vi tror inte heller på
                utsätta sina kunder för långdragna processer av blanketter, korrespondens och telefonköer.
                Genom att jämföra alla försäkringsbolag på marknaden istället för bara ett fåtal med avtal utmanas
                ditt avtal mellan alla bolag.
            </p>
            <p className="text-center text-sm-left">
                Att välja rätt försäkring utifrån sina egna behov uppfattas ofta vara både en lång men
                framförallt komplicerad process.  Därför  skapade vi Nya Försäkringar.
            </p>
        </section>
    )
};

export default Description;
