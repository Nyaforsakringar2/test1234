import Hero from './Hero';
import Description from './Description';
import AnnouncePage from './AnnouncePage';

export {
    Hero,
    Description,
    AnnouncePage
};
