import React from 'react';
import * as s from '../../styles/Omoss/Hero.module.css';

const Hero = () => {
    return (
        <section className={s.sectionContainer}>
            <h1>Vi serverar Nya Försäkringar</h1>
        </section>
    )
};

export default Hero;
