import React, { useState, useEffect } from 'react';
import MinaSidor from '../components/MinaSidor/';

export default () => <MinaSidor />;
