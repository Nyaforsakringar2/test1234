import React, { useState, useEffect } from 'react';

export default function readMore() {
    return (
        <div style={{width: "100%"}}>
            <h1>
                Comming soon
            </h1>
        </div>
    );
}
