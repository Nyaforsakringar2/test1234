import { Hero, Description, AnnouncePage } from '../components/Omoss';
import { Header, PreFooter, FooterBlock } from '../components/shared';
import * as s from '../styles/Omoss/PreFooter.module.css';

export default function OmOss() {
  return (
    <>
      <Header />
      <Hero />
      <Description />
      <AnnouncePage />
      <PreFooter className={s.preFooterContainer} />
      <FooterBlock />
    </>
  );
}
