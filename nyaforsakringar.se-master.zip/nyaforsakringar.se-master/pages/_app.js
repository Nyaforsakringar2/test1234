import 'bootstrap/dist/css/bootstrap.min.css';
import globalCSSPlain from '../styles/global.js'
import globalCSSModule from '../styles/Global.module.css';
import React from 'react';
import App from 'next/app';
import Head from 'next/head';
import {IntlProvider, useIntl} from 'react-intl';
import { IntlProviderWrapper } from '../locales/IntlProviderWrapper';
import { Container } from 'react-bootstrap';

export default class MyApp extends App {

    constructor(props) {
        super(props);
        this.state = {
            currentLocale: "en"
        }
    }

    // componentDidMount() {
    //     const defaultLocale = localStorage['locale'] ? localStorage['locale'] : 'en'; // English is default locale if none is set
    //     this.setState({
    //         currentLocale: defaultLocale
    //     })
    // }

    setCurrentLocale = (locale) => {
        this.setState({
            currentLocale: locale
        })
    };

    static async getInitialProps({ Component, router, ctx }) {
        let pageProps = {};

        if (Component.getInitialProps) {
            pageProps = await Component.getInitialProps(ctx);
        }

        return { pageProps };
    }

    render() {
        const { Component, pageProps } = this.props;

        return (
            <IntlProviderWrapper>
                <Head>
                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
                    <link rel="preload" href="/fonts/Roboto-Regular.woff2" as="font" crossOrigin="" />
                </Head>

                <Container fluid className={globalCSSModule.pageContainer}>
                    <Component {...pageProps} />
                </Container>

                <style global jsx>
                    {globalCSSPlain}
                </style>
            </IntlProviderWrapper>
        );
    }
}
