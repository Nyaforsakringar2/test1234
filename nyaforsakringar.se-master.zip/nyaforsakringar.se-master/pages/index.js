import {
  Header,
  ComparePoliciesBlock,
  VideoBlock,
  ClaimsServiceBlock,
  IconsBlock,
  BottomBlock,
  PreFooter,
  FooterBlock
} from '../components/Index';

export default function Index() {
    return (
        <>
            <Header />
            <ComparePoliciesBlock />
            <VideoBlock />
            <ClaimsServiceBlock />
            <IconsBlock />
            <BottomBlock />
            <PreFooter />
            <FooterBlock />
        </>
    );
}
