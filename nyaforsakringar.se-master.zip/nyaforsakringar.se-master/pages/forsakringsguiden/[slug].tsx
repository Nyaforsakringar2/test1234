import React from 'react';
import { NextPage } from 'next';
import { Post as BlogPost } from '../../blog/interfaces/post'
import {
    EmailSubscription,
    BlogPostHeader,
    BlogPostContent,
    SuggestedPosts
} from '../../blog/components';
import { Header, FooterBlock } from '../../components/shared';
import { ContentfulService } from '../../blog/services/contentful';

type Props = {
    article: BlogPost;
    suggestedArticles: BlogPost[]
};

const Post: NextPage<Props, any> = (props: Props) => (
    <>
        <Header/>
        <BlogPostHeader {...props} />
        <BlogPostContent {...props} />
        <SuggestedPosts {...props} />
        <EmailSubscription/>
        <FooterBlock/>
    </>
);

Post.getInitialProps = async ({query}) => {
    const contentfulService = new ContentfulService();

    const {slug} = query;
    const article = await contentfulService.getPostBySlug(slug);
    let suggestedArticles = await contentfulService.getBlogPostEntries({
        tag: article.tags[0].id,
        limit: 3,
        excludePostIds: article.id.toString()
    });
    if (!suggestedArticles.total) {
        suggestedArticles = await contentfulService.getBlogPostEntries({
            limit: 3,
        });
    }

    return {article, suggestedArticles};
};

export default Post;
