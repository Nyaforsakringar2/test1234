import React from 'react';
import { NextPage, NextPageContext } from 'next';
import { Hero, BlogPostsList, EmailSubscription } from '../blog/components/';
import { Header, FooterBlock } from '../components/shared';
import { ContentfulService } from '../blog/services/contentful';
import { Post } from '../blog/interfaces/post';

type Props = {
    entries: Post[];
    tags: { id: string, name: string }[];
    url: any;
    total: number;
    skip: number;
    limit: number;
    page?: number;
}

const Forsakringsguiden: NextPage<Props, any> = (props: Props) => {
  return (
      <>
        <Header />
        <Hero />
        <BlogPostsList {...props} />
        <EmailSubscription />
        <FooterBlock />
      </>
  );
};

Forsakringsguiden.getInitialProps = async ({query}: NextPageContext) => {
    const contentfulService = new ContentfulService();
    const limitFromQuery = query.s ? Number(query.s) : 9;
    const {entries, total, limit} = await contentfulService.getBlogPostEntries({
        tag: query.t ? query.t.toString() : '',
        limit: limitFromQuery
    });
    const {tags} = await contentfulService.getAllTags();

    return {tags, entries, total, limit};
};

export default Forsakringsguiden;
