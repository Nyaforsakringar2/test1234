import React, { useState, useEffect } from 'react';

export default () => {
  return <h1>jamfor</h1>;
};
