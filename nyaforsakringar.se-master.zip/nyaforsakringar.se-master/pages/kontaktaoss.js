import { Header, FooterBlock } from '../components/shared';
import { ContactInfo, PreFooter } from '../components/KontaktaOss';

export default function KontaktaOss() {
  return (
      <>
        <Header />
        <ContactInfo />
        <PreFooter />
        <FooterBlock />
      </>
  );
}
