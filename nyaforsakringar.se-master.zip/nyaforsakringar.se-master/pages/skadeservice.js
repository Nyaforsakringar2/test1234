import { Hero, Challenges, Solution } from '../components/Skadeservice/';
import { Header, PreFooter, FooterBlock } from '../components/shared';
import * as s from '../styles/Skadeservice/PreFooter.module.css';

export default function Skadeservice() {
    return (
        <>
          <Header />
          <Hero />
          <Challenges />
          <Solution />
          <PreFooter className={s.preFooterContainer} />
          <FooterBlock />
        </>
    );
};
