import { Hero, CompareInfo, AnnouncePage, InsuranceDetails } from '../components/Forsakringsservice/';
import { Header, PreFooter, FooterBlock } from '../components/shared';
import * as s from '../styles/Forsakringsservice/PreFooter.module.css';

export default function Forsakringsservice() {
  return (
    <>
      <Header />
      <Hero />
      <CompareInfo />
      <AnnouncePage />
      <InsuranceDetails />
      <PreFooter className={s.preFooterContainer} />
      <FooterBlock />
    </>
  );
};
