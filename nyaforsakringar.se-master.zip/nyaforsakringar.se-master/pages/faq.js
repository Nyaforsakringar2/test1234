import { FaqInfo } from '../components/FAQ';
import { Header, FooterBlock, PreFooter } from '../components/shared';
import * as s from '../styles/FAQ/PreFooter.module.css';

export default function OmOss() {
  return (
      <>
        <Header />
        <FaqInfo />
        <PreFooter className={s.preFooterContainer} />
        <FooterBlock />
      </>
  );
}
