import css from 'styled-jsx/css';

export default css.global`
  @font-face {
    font-family: 'Roboto';
    font-style: normal;
    font-weight: 400;
    font-display: swap;
    src: url('/fonts/Roboto-Regular.woff2') format('woff2'),
         url('/fonts/Roboto-Regular.woff') format('woff'),
         url('/fonts/Roboto-Regular.ttf') format('truetype')
  }
  html, body {
    overflow: auto;
    width: 100%;
    height: 100%;
    margin: 0;
    padding: 0;
  }
  html {
    font-size: 16px;
  }
  body {
    font-family: Roboto, sans-serif;
    background-color: #ffffff;
  }
  #__next {
    overflow: hidden;
  }
  ul {
    margin: 0;
    padding: 0;
    list-style: none;
  }
  body p:hover, body span:hover, h1:hover, h2:hover {
    color: #ff7f00;
  }
  a:focus {
    outline: thin dotted;
  }
  body a:active, body a:hover {
    outline: 0;
    text-decoration: none;
    color: #ff7f00;
  }
`
